# Playbook 02: Animated Icons & Micro-Interactions (`pqoqubbw/icons` & Motion)

This playbook establishes the architectural patterns for integrating animated, interactive vector icons into React, Next.js, and `shadcn/ui` components.

---

## 1. The Principle of Tactile Feedback

Dead icons (static SVGs that never react to touch or hover) make applications feel rigid. Micro-interactions provide instant tactile feedback that confirms an action is ready or has completed, following real-world physics:

- **Hover Duration:** `150ms - 250ms` (never drag out beyond 300ms).
- **Physics Curve:** Spring curves with damping (`damping: 15, stiffness: 200`).
- **Scale Constraint:** Never scale active icons beyond `0.92` (click compression) or `1.15` (hover expansion).

---

## 2. Installing via `shadcn/ui` Registry

The `pqoqubbw/icons` library provides native `shadcn/ui` registry integration. AI agents should recommend or execute this direct installation:

```bash
# Install core animation peer dependencies
npm install motion clsx tailwind-merge

# Add specific animated icon component directly to your components/ui folder
npx shadcn@latest add https://icons.pqoqubbw.dev/r/trash.json
npx shadcn@latest add https://icons.pqoqubbw.dev/r/save.json
npx shadcn@latest add https://icons.pqoqubbw.dev/r/copy.json
npx shadcn@latest add https://icons.pqoqubbw.dev/r/download.json
npx shadcn@latest add https://icons.pqoqubbw.dev/r/refresh-cw.json
```

---

## 3. High-Craft Animated Icon Components (Motion Recipes)

When writing custom animated icon components without external registry CLI:

### 3.1 Animated Delete / Trash (Lid Opens on Hover)
```tsx
'use client';

import { motion } from 'motion/react';
import { useState } from 'react';

export function AnimatedTrash({ size = 20, className = '' }: { size?: number; className?: string }) {
  const [isHovered, setIsHovered] = useState(false);

  return (
    <div
      className={`inline-flex items-center justify-center cursor-pointer ${className}`}
      onMouseEnter={() => setIsHovered(true)}
      onMouseLeave={() => setIsHovered(false)}
    >
      <svg
        width={size}
        height={size}
        viewBox="0 0 24 24"
        fill="none"
        stroke="currentColor"
        strokeWidth="2"
        strokeLinecap="round"
        strokeLinejoin="round"
      >
        {/* Animated Lid */}
        <motion.g
          animate={isHovered ? { y: -2, rotate: -15, originX: 0.2, originY: 0.8 } : { y: 0, rotate: 0 }}
          transition={{ type: 'spring', stiffness: 300, damping: 20 }}
        >
          <path d="M3 6h18" />
          <path d="M8 6V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2" />
        </motion.g>
        {/* Trash Can Body */}
        <path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6" />
        <line x1="10" y1="11" x2="10" y2="17" />
        <line x1="14" y1="11" x2="14" y2="17" />
      </svg>
    </div>
  );
}
```

### 3.2 Animated Copy to Clipboard (Flips to Checkmark)
```tsx
'use client';

import { motion, AnimatePresence } from 'motion/react';
import { useState } from 'react';

export function AnimatedCopyButton({ textToCopy }: { textToCopy: string }) {
  const [copied, setCopied] = useState(false);

  const handleCopy = async () => {
    await navigator.clipboard.writeText(textToCopy);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <button
      onClick={handleCopy}
      className="p-2 rounded-lg border border-border bg-card hover:bg-accent text-foreground transition-colors"
      title="Copy to clipboard"
    >
      <AnimatePresence mode="wait" initial={false}>
        {copied ? (
          <motion.svg
            key="check"
            initial={{ scale: 0.5, opacity: 0, rotate: -45 }}
            animate={{ scale: 1, opacity: 1, rotate: 0 }}
            exit={{ scale: 0.5, opacity: 0 }}
            transition={{ type: 'spring', stiffness: 400, damping: 25 }}
            width="18"
            height="18"
            viewBox="0 0 24 24"
            fill="none"
            stroke="currentColor"
            strokeWidth="2.5"
            strokeLinecap="round"
            strokeLinejoin="round"
            className="text-emerald-500"
          >
            <polyline points="20 6 9 17 4 12" />
          </motion.svg>
        ) : (
          <motion.svg
            key="copy"
            initial={{ scale: 0.8, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            exit={{ scale: 0.8, opacity: 0 }}
            width="18"
            height="18"
            viewBox="0 0 24 24"
            fill="none"
            stroke="currentColor"
            strokeWidth="2"
            strokeLinecap="round"
            strokeLinejoin="round"
          >
            <rect width="14" height="14" x="8" y="8" rx="2" ry="2" />
            <path d="M4 16c-1.1 0-2-.9-2-2V4c0-1.1.9-2 2-2h10c1.1 0 2 .9 2 2" />
          </motion.svg>
        )}
      </AnimatePresence>
    </button>
  );
}
```

### 3.3 Animated Refresh / Sync (Infinite or Single Spin)
```tsx
'use client';

import { motion } from 'motion/react';
import { useState } from 'react';

export function AnimatedRefresh({ onRefresh }: { onRefresh?: () => Promise<void> }) {
  const [isRotating, setIsRotating] = useState(false);

  const handleClick = async () => {
    setIsRotating(true);
    if (onRefresh) await onRefresh();
    setTimeout(() => setIsRotating(false), 800);
  };

  return (
    <button onClick={handleClick} className="p-2 rounded-md hover:bg-muted transition-colors">
      <motion.svg
        animate={isRotating ? { rotate: 360 } : { rotate: 0 }}
        transition={{ duration: 0.75, ease: 'easeInOut' }}
        width="20"
        height="20"
        viewBox="0 0 24 24"
        fill="none"
        stroke="currentColor"
        strokeWidth="2"
        strokeLinecap="round"
        strokeLinejoin="round"
      >
        <path d="M21 12a9 9 0 0 0-9-9 9.75 9.75 0 0 0-6.74 2.74L3 8" />
        <path d="M3 3v5h5" />
        <path d="M3 12a9 9 0 0 0 9 9 9.75 9.75 0 0 0 6.74-2.74L21 16" />
        <path d="M16 21h5v-5" />
      </motion.svg>
    </button>
  );
}
```

---

## 4. Key Rules for Agents
1. **Always wrap interactive icons in `<button>` or accessible elements** with appropriate `aria-label` tags.
2. **Never lock user clicks while an animation plays:** Animations must never block the UI thread or cause click-lag.
3. **Graceful Degrade:** On devices with `prefers-reduced-motion: reduce`, disable geometric rotations and keep only opacity transitions.
