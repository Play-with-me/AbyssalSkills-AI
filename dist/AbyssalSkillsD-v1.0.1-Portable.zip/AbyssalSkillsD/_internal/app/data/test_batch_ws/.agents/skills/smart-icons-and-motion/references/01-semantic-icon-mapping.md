# Playbook 01: Semantic Icon Mapping Matrix

This directory maps application domain concepts, user intents, and functional features directly to exact, canonical **Lucide Icons** and **Iconify Queries**. 

AI agents must consult this matrix before creating components to prevent hallucinating non-existent icon names or choosing ambiguous visuals.

---

## 1. Domain-Specific Feature Mappings

### 1.1 E-Commerce, Fintech & Billing
| Feature / User Intent | Canonical Lucide Icon | Iconify Query / Alternative | Visual Meaning |
| :--- | :--- | :--- | :--- |
| **Refund / Chargeback** | `RotateCcw`, `ReceiptRefund` | `lucide:rotate-ccw`, `heroicons:arrow-uturn-left` | Reverse money flow |
| **Wallet / Balance** | `Wallet`, `CreditCard` | `lucide:wallet`, `solar:wallet-bold` | Current digital assets |
| **Invoice / Receipt** | `Receipt`, `FileText` | `lucide:receipt`, `tabler:receipt-tax` | Official payment document |
| **Split Bill / Transfer** | `Split`, `ArrowLeftRight` | `lucide:split`, `ph:arrows-split` | Distribute expenses |
| **Discount / Voucher** | `TicketPercent`, `Tag` | `lucide:ticket-percent` | Promotional coupon |
| **Subscription / Recurring** | `RefreshCw`, `CalendarClock` | `lucide:refresh-cw` | Automated recurring charge |
| **Shopping Cart / Checkout** | `ShoppingCart`, `ShoppingBag` | `lucide:shopping-cart` | Items pending purchase |
| **Crypto / Web3** | `Coins`, `Gem` | `lucide:coins`, `tabler:currency-bitcoin` | Digital tokens |

### 1.2 Auth, Identity & Security
| Feature / User Intent | Canonical Lucide Icon | Iconify Query / Alternative | Visual Meaning |
| :--- | :--- | :--- | :--- |
| **Biometrics (Face/Touch ID)** | `Fingerprint`, `ScanFace` | `lucide:fingerprint`, `lucide:scan-face` | Hardware authentication |
| **Two-Factor Auth (2FA)** | `Smartphone`, `KeyRound` | `lucide:key-round`, `ph:shield-checkered` | Second verification device |
| **Single Sign-On (SSO)** | `ShieldCheck`, `Fingerprint` | `lucide:shield-check` | Corporate identity login |
| **Permission / Access Level** | `Lock`, `Unlock`, `UserCheck` | `lucide:lock`, `solar:shield-user-bold` | Role-based permission (RBAC) |
| **Security Audit / Log** | `ShieldAlert`, `FileCheck` | `lucide:shield-alert` | Vulnerability assessment |
| **Logout / Sign Out** | `LogOut` | `lucide:log-out` | Gracefully end session |

### 1.3 AI, Machine Learning & Automation
| Feature / User Intent | Canonical Lucide Icon | Iconify Query / Alternative | Visual Meaning |
| :--- | :--- | :--- | :--- |
| **AI Assistant / Copilot** | `Sparkles`, `Bot` | `lucide:sparkles`, `solar:magic-stick-bold` | Generative intelligence |
| **Prompt / Prompt Engineering** | `Terminal`, `MessageSquareCode` | `lucide:terminal` | User command input |
| **Neural Net / Brain** | `Brain`, `Cpu` | `lucide:brain`, `ph:brain` | Knowledge engine / Model weights |
| **Model Fine-Tuning** | `Sliders`, `Wrench` | `lucide:sliders` | Parameter adjustment |
| **Embedding / Vector Search** | `Boxes`, `SearchCode` | `lucide:boxes`, `tabler:vector-bezier` | High-dimensional data points |
| **Speech-to-Text / Audio AI** | `Mic`, `AudioLines` | `lucide:mic`, `lucide:audio-lines` | Voice recognition |

### 1.4 Data Analytics, Reports & Dashboards
| Feature / User Intent | Canonical Lucide Icon | Iconify Query / Alternative | Visual Meaning |
| :--- | :--- | :--- | :--- |
| **Growth / Positive Trend** | `TrendingUp`, `ArrowUpRight` | `lucide:trending-up` | Revenue or conversion increase |
| **Decline / Negative Trend** | `TrendingDown`, `ArrowDownRight` | `lucide:trending-down` | Churn or bounce increase |
| **Funnel Analysis** | `Filter`, `GitCommitVertical` | `lucide:filter`, `tabler:filter` | Multi-step dropoff rate |
| **Heatmap / Distribution** | `Grid3x3`, `LayoutGrid` | `lucide:grid-3x3` | Cluster density |
| **Realtime Metric / Speed** | `Gauge`, `Activity` | `lucide:gauge`, `lucide:activity` | Latency / Live telemetry |
| **Export CSV / PDF** | `Download`, `FileSpreadsheet` | `lucide:file-spreadsheet` | Download report file |

### 1.5 Content, Media & Productivity
| Feature / User Intent | Canonical Lucide Icon | Iconify Query / Alternative | Visual Meaning |
| :--- | :--- | :--- | :--- |
| **Save / Bookmark** | `Bookmark`, `Save` | `lucide:bookmark`, `lucide:save` | Persist for later |
| **Favorite / Like** | `Heart`, `ThumbsUp` | `lucide:heart`, `solar:heart-bold` | User appreciation |
| **Copy Link / Text** | `Copy`, `Link` | `lucide:copy`, `lucide:link` | Clipboard operation |
| **Share / Broadcast** | `Share2`, `Send` | `lucide:share-2` | Social dissemination |
| **Dark / Light Mode** | `Moon`, `Sun` | `lucide:moon`, `lucide:sun` | Theme switching |
| **Settings / Config** | `Settings`, `SlidersHorizontal` | `lucide:settings` | System preferences |

---

## 2. Dynamic Iconify Query Syntax

When building dynamic search or fetching icons on the fly via Iconify API:

```typescript
// Querying Iconify public API for exact SVG data
async function fetchSemanticIcon(keyword: string): Promise<string> {
  const cleanKeyword = encodeURIComponent(keyword.trim().toLowerCase());
  const response = await fetch(`https://api.iconify.design/search?query=${cleanKeyword}&limit=1`);
  const data = await response.json();
  
  if (data.icons && data.icons.length > 0) {
    const iconName = data.icons[0]; // e.g., 'lucide:sparkles'
    const [prefix, name] = iconName.split(':');
    return `https://api.iconify.design/${prefix}/${name}.svg`;
  }
  
  // Safe Fallback
  return `https://api.iconify.design/lucide/help-circle.svg`;
}
```
