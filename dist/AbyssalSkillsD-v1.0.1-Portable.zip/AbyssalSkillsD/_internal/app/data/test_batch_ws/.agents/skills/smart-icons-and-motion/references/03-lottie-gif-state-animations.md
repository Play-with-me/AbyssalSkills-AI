# Playbook 03: Lottie & GIF State Feedback Animations

This playbook establishes the integration standards for state feedback animations (Lottie `.lottie`/`.json` and lightweight animated GIFs) across the 5 canonical UX application states.

---

## 1. The 5 Canonical UX Feedback States

Every asynchronous task, form submission, or empty screen in an application must map to one of these 5 visual states:

```
┌─────────────────────────────────────────────────────────────────────────┐
│                      5-STATE UX ANIMATION MATRIX                        │
├──────────────┬────────────────────────┬─────────────────────────────────┤
│ State        │ Visual Behavior        │ Recommended Asset / Source      │
├──────────────┼────────────────────────┼─────────────────────────────────┤
│ 1. Loading   │ Infinite smooth rhythm │ DotLottie Spinner / Pulse Wave  │
│ 2. Success   │ Spring checkmark burst │ Lottie Checkmark / `useAnim`    │
│ 3. Error     │ Horizontal 3-tap shake │ Shake keyframe / Alert wobble   │
│ 4. Empty     │ Slow floating physics  │ Floating Box / Open Document    │
│ 5. Milestone │ Confetti particle rain │ Canvas Confetti / Lottie Party  │
└──────────────┴────────────────────────┴─────────────────────────────────┘
```

---

## 2. Web Player Integration (Next.js & React)

### 2.1 Using `@lottiefiles/dotlottie-react` (High-Performance WebAssembly)
DotLottie files are up to 80% smaller than legacy Lottie JSON and 90% lighter than traditional animated GIFs:

```bash
npm install @lottiefiles/dotlottie-react
```

```tsx
'use client';

import { DotLottieReact } from '@lottiefiles/dotlottie-react';

interface StateFeedbackProps {
  type: 'loading' | 'success' | 'empty' | 'error';
  title: string;
  description?: string;
}

export function StateFeedback({ type, title, description }: StateFeedbackProps) {
  const animationSrc = {
    loading: 'https://assets.lottiefiles.com/packages/lf20_p8bfn5to.json',
    success: 'https://assets.lottiefiles.com/packages/lf20_jbrw3hcz.json',
    empty: 'https://assets.lottiefiles.com/packages/lf20_m6cu9m9a.json',
    error: 'https://assets.lottiefiles.com/packages/lf20_t24tpvcu.json',
  }[type];

  return (
    <div className="flex flex-col items-center justify-center p-8 text-center max-w-sm mx-auto">
      <div className="w-32 h-32 mb-4">
        <DotLottieReact
          src={animationSrc}
          loop={type === 'loading' || type === 'empty'}
          autoplay
        />
      </div>
      <h3 className="text-lg font-semibold text-foreground tracking-tight">{title}</h3>
      {description && <p className="text-sm text-muted-foreground mt-1">{description}</p>}
    </div>
  );
}
```

---

## 3. Lightweight CSS & GIF Fallback (Zero Dependency)

When you do not want to install external player packages, use CSS spring keyframes with SVGs or optimized GIF assets:

### 3.1 Error Shake Keyframe (Tailwind CSS)
```css
/* Add to globals.css */
@keyframes errorShake {
  0%, 100% { transform: translateX(0); }
  20%, 60% { transform: translateX(-6px); }
  40%, 80% { transform: translateX(6px); }
}

.animate-error-shake {
  animation: errorShake 0.4s cubic-bezier(0.36, 0.07, 0.19, 0.97) both;
}
```

### 3.2 Milestone Confetti (Canvas-Confetti Recipe)
```bash
npm install canvas-confetti
npm install --save-dev @types/canvas-confetti
```

```typescript
import confetti from 'canvas-confetti';

export function triggerMilestoneCelebration() {
  const count = 200;
  const defaults = {
    origin: { y: 0.7 },
    zIndex: 9999,
  };

  function fire(particleRatio: number, opts: confetti.Options) {
    confetti({
      ...defaults,
      ...opts,
      particleCount: Math.floor(count * particleRatio),
    });
  }

  fire(0.25, { spread: 26, startVelocity: 55 });
  fire(0.2, { spread: 60 });
  fire(0.35, { spread: 100, decay: 0.91, scalar: 0.8 });
  fire(0.1, { spread: 120, startVelocity: 25, decay: 0.92, scalar: 1.2 });
  fire(0.1, { spread: 120, startVelocity: 45 });
}
```

---

## 4. Anti-Slop & Performance Rules
1. **Never autoplay looping GIFs with flashing colors:** Use muted brand tones (500-600 palette) and smooth transitions to avoid triggering photosensitivity.
2. **Always unmount Lottie / GIF when hidden:** Keep background tabs and hidden modals paused to avoid draining battery and CPU cycles.
3. **Empty States Must Include a Direct Call to Action (CTA):** Never display an empty animation without a button to remedy the state (e.g., "Tạo tài liệu đầu tiên", "Nạp tiền vào ví").
